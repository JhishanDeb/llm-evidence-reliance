# Scale check: diagnostic of the next token after "Answer:" (dev prompts only)

Code main-2.0 (0ba0853b4b52b897), plan scale-plan (f2c1bba028998a98). Engineering only: no accuracy, no asymmetry, no rule changed.

## Qwen/Qwen3-8B-AWQ

**yesno** (54 prompts): answer-word mass median 0.966

| next token | mean probability |
|---|---|
| `' No'` | 0.724 |
| `' **'` | 0.139 |
| `' Yes'` | 0.137 |
| `' Maybe'` | 0.000 |
| `' Possibly'` | 0.000 |
| `' Likely'` | 0.000 |
| `' Probably'` | 0.000 |
| `' Possible'` | 0.000 |
| `' Unknown'` | 0.000 |
| `' *'` | 0.000 |
| `'No'` | 0.000 |
| `' _'` | 0.000 |
| `'Yes'` | 0.000 |
| `' The'` | 0.000 |
| `' Not'` | 0.000 |

Greedy continuations after "Answer:":

- `' Yes'`
- `' Yes'`
- `' **Yes**'`
- `' Yes'`
- `' Yes\n\n**Reasoning:**\n\nThe machine learning model (XGBoost)'`
- `' No\n\n**Reasoning:**\n\nThe machine learning model (XGBoost)'`
- `' No'`
- `' No'`

**choice** (54 prompts): answer-word mass median 0.783

| next token | mean probability |
|---|---|
| `' B'` | 0.524 |
| `' **'` | 0.250 |
| `' A'` | 0.225 |
| `' _'` | 0.000 |
| `' D'` | 0.000 |
| `' __'` | 0.000 |
| `' $'` | 0.000 |
| `' *'` | 0.000 |
| `' C'` | 0.000 |
| `' $\\'` | 0.000 |
| `' The'` | 0.000 |
| `'  \n'` | 0.000 |
| `' AB'` | 0.000 |
| `'**'` | 0.000 |
| `' Based'` | 0.000 |

Greedy continuations after "Answer:":

- `' A'`
- `' B'`
- `' A'`
- `' B'`
- `' **A**'`
- `' B\n\n**Reasoning:**\n\nThe machine learning model (XGBoost)'`
- `' A'`
- `' B'`

**sanity** (4 prompts): answer-word mass median 1.000

| next token | mean probability |
|---|---|
| `' A'` | 0.250 |
| `' No'` | 0.250 |
| `' B'` | 0.250 |
| `' Yes'` | 0.248 |
| `' **'` | 0.002 |
| `'  \n'` | 0.000 |
| `' YES'` | 0.000 |
| `'Yes'` | 0.000 |
| `' yes'` | 0.000 |
| `'No'` | 0.000 |
| `' \\'` | 0.000 |
| `' Y'` | 0.000 |
| `' The'` | 0.000 |
| `' '` | 0.000 |
| `' _'` | 0.000 |

Greedy continuations after "Answer:":

- `' Yes.'`
- `' No.'`
- `' A'`
- `' B'`

## Qwen/Qwen3-14B-AWQ

**yesno** (54 prompts): answer-word mass median 0.183

| next token | mean probability |
|---|---|
| `' **'` | 0.646 |
| `' No'` | 0.260 |
| `' Yes'` | 0.095 |
| `' Unknown'` | 0.000 |
| `'Yes'` | 0.000 |
| `' YES'` | 0.000 |
| `'No'` | 0.000 |
| `',Yes'` | 0.000 |
| `' Maybe'` | 0.000 |
| `'**'` | 0.000 |
| `' Not'` | 0.000 |
| `'.No'` | 0.000 |
| `'-No'` | 0.000 |
| `' yes'` | 0.000 |
| `',No'` | 0.000 |

Greedy continuations after "Answer:":

- `' Yes'`
- `' Yes'`
- `' **Yes**'`
- `' Yes'`
- `' Yes'`
- `' No'`
- `' No'`
- `' No'`

**choice** (54 prompts): answer-word mass median 0.034

| next token | mean probability |
|---|---|
| `' **'` | 0.903 |
| `' A'` | 0.067 |
| `' B'` | 0.030 |
| `' $'` | 0.000 |
| `' $\\'` | 0.000 |
| `' __'` | 0.000 |
| `'**'` | 0.000 |
| `' А'` | 0.000 |
| `' (**'` | 0.000 |
| `' ***'` | 0.000 |
| `' *'` | 0.000 |
| `' C'` | 0.000 |
| `' �'` | 0.000 |
| `'\tA'` | 0.000 |
| `' \\'` | 0.000 |

Greedy continuations after "Answer:":

- `' **A**'`
- `' **B**'`
- `' **A**'`
- `' **B**'`
- `' **A**'`
- `' **B**'`
- `' **A**'`
- `' **B**'`

**sanity** (4 prompts): answer-word mass median 1.000

| next token | mean probability |
|---|---|
| `' No'` | 0.250 |
| `' Yes'` | 0.250 |
| `' A'` | 0.250 |
| `' B'` | 0.250 |
| `' **'` | 0.000 |
| `'  \n'` | 0.000 |
| `' YES'` | 0.000 |
| `'No'` | 0.000 |
| `'Yes'` | 0.000 |
| `',Yes'` | 0.000 |
| `' Fire'` | 0.000 |
| `'-No'` | 0.000 |
| `'.Yes'` | 0.000 |
| `'\xa0'` | 0.000 |
| `' yes'` | 0.000 |

Greedy continuations after "Answer:":

- `' Yes.'`
- `' No.'`
- `' A'`
- `' B'`

## Qwen/Qwen3-32B-AWQ

**yesno** (54 prompts): answer-word mass median 0.182

| next token | mean probability |
|---|---|
| `' **'` | 0.756 |
| `' No'` | 0.208 |
| `' Yes'` | 0.035 |
| `'Yes'` | 0.000 |
| `'No'` | 0.000 |
| `' Unknown'` | 0.000 |
| `' YES'` | 0.000 |
| `' __'` | 0.000 |
| `' yes'` | 0.000 |
| `' _'` | 0.000 |
| `' Likely'` | 0.000 |
| `'_No'` | 0.000 |
| `' Not'` | 0.000 |
| `'**'` | 0.000 |
| `'_no'` | 0.000 |

Greedy continuations after "Answer:":

- `' **Yes**'`
- `' **Yes**'`
- `' **Yes**'`
- `' **Yes**'`
- `' **Yes**'`
- `' No'`
- `' **No**'`
- `' No'`

**choice** (54 prompts): answer-word mass median 0.127

| next token | mean probability |
|---|---|
| `' **'` | 0.849 |
| `' A'` | 0.095 |
| `' B'` | 0.056 |
| `' __'` | 0.000 |
| `' _'` | 0.000 |
| `' ***'` | 0.000 |
| `' *'` | 0.000 |
| `' D'` | 0.000 |
| `' '` | 0.000 |
| `' C'` | 0.000 |
| `' $'` | 0.000 |
| `' The'` | 0.000 |
| `' (**'` | 0.000 |
| `'**'` | 0.000 |
| `' А'` | 0.000 |

Greedy continuations after "Answer:":

- `' **A**'`
- `' **B**'`
- `' **A**'`
- `' **B**'`
- `' **A**'`
- `' **B**'`
- `' **A**'`
- `' **B**'`

**sanity** (4 prompts): answer-word mass median 0.978

| next token | mean probability |
|---|---|
| `' A'` | 0.245 |
| `' B'` | 0.244 |
| `' Yes'` | 0.231 |
| `' No'` | 0.226 |
| `' **'` | 0.053 |
| `'  \n'` | 0.000 |
| `' Blue'` | 0.000 |
| `' YES'` | 0.000 |
| `' $'` | 0.000 |
| `'Yes'` | 0.000 |
| `' �'` | 0.000 |
| `' yes'` | 0.000 |
| `' _'` | 0.000 |
| `' $\\'` | 0.000 |
| `' ___'` | 0.000 |

Greedy continuations after "Answer:":

- `' Yes.'`
- `' No.'`
- `' A'`
- `' B'`
