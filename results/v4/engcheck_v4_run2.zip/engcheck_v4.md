# Engineering check, fourth study

|                       | 0                                                             | 1                                                                    | 2                                                             |
|:----------------------|:--------------------------------------------------------------|:---------------------------------------------------------------------|:--------------------------------------------------------------|
| model                 | meta-llama/Llama-3.1-8B-Instruct                              | Qwen/Qwen2.5-7B-Instruct                                             | meta-llama/Llama-3.1-8B                                       |
| kind                  | instruct                                                      | instruct                                                             | base                                                          |
| ok                    | True                                                          | True                                                                 | True                                                          |
| revision              | 0e9e39f249a1                                                  | a09a35458c70                                                         | d04e592bb4f6                                                  |
| window                | 16384                                                         | 16384                                                                | 16384                                                         |
| tokens_max            | 2101                                                          | 2238                                                                 | 2089                                                          |
| exact_yn              | 0.0156                                                        | 0.0469                                                               | 0.0112                                                        |
| exact_tf              | 0.0139                                                        | 0.0312                                                               | nan                                                           |
| imputed_timing        | 0.0                                                           | 0.1467                                                               | 0.0                                                           |
| s_per_prompt          | 0.4073                                                        | 0.3906                                                               | 0.4016                                                        |
| projected_scoring_h   | 6.31                                                          | 6.05                                                                 | 2.41                                                          |
| sanity                | yyyy                                                          | yyyy                                                                 | yyny                                                          |
| parsed_prefill        | 1.0                                                           | 1.0                                                                  | nan                                                           |
| parsed_free           | 0.2778                                                        | 0.4444                                                               | nan                                                           |
| chat_tokens_identical |                                                               |                                                                      | True                                                          |
| formats_ok            | split,tf,neg,order,para,aggr,plain                            | split,tf,neg,order,para,aggr,plain                                   | split,chat                                                    |
| formats_failed        |                                                               |                                                                      |                                                               |
| system_text           | Cutting Knowledge Date: December 2023 Today Date: 26 Jul 2024 | You are Qwen, created by Alibaba Cloud. You are a helpful assistant. | Cutting Knowledge Date: December 2023 Today Date: 26 Jul 2024 |
| mass alarm|Acue       | 0.9899                                                        | 0.9989                                                               | nan                                                           |
| mass alarm|Anet       | 0.9878                                                        | 0.9898                                                               | nan                                                           |
| mass negated|A        | 0.9922                                                        | 0.9999                                                               | nan                                                           |
| mass alarm|Asf        | 0.9907                                                        | 0.9972                                                               | nan                                                           |
| mass reversed|Asf     | 0.9901                                                        | 0.9985                                                               | nan                                                           |
| mass para_alarm|A     | 0.9913                                                        | 0.9996                                                               | nan                                                           |
| mass para_reversed|A  | 0.9941                                                        | 1.0                                                                  | nan                                                           |
| mass alarm|Abase      | 0.8235                                                        | 0.9675                                                               | nan                                                           |
| mass reversed|Abase   | 0.8558                                                        | 0.9889                                                               | nan                                                           |
| mass alarm|A          | 0.9886                                                        | 0.9955                                                               | 0.738                                                         |
| mass reversed|A       | 0.9923                                                        | 0.9995                                                               | 0.7612                                                        |
| mass tf_alarm|A       | 0.9869                                                        | 0.9991                                                               | nan                                                           |
| mass tf_reversed|A    | 0.9877                                                        | 0.9998                                                               | nan                                                           |
| mass alarm|Achat      | nan                                                           | nan                                                                  | 0.6538                                                        |
| mass reversed|Achat   | nan                                                           | nan                                                                  | 0.6702                                                        |

## Problems

- meta-llama/Llama-3.1-8B-Instruct: none
- Qwen/Qwen2.5-7B-Instruct: none
- meta-llama/Llama-3.1-8B: none

## Decisions

{"formats_not_run": {"olmo3-instruct": ["tf", "neg", "order", "para", "aggr"], "falcon3-7b": ["tf", "neg", "order", "para", "aggr"], "yi15-9b": ["tf", "neg", "order", "para", "aggr"]}, "plain_run": ["llama-instruct"], "r10_families": ["llama"]}
