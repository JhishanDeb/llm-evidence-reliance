# Engineering check, fifth study

|                            | 0                        |
|:---------------------------|:-------------------------|
| model                      | 01-ai/Yi-1.5-9B-Chat-16K |
| ok                         | True                     |
| revision                   | 2f8753bed95b             |
| window                     | 16384                    |
| tokens_max                 | 2441                     |
| exact_yn                   | 0.0242                   |
| exact_tf                   | 0.0302                   |
| exact_ab                   | 0.0266                   |
| imputed_timing             | 0.0                      |
| s_per_prompt               | 0.7475                   |
| projected_scoring_h        | 9.96                     |
| projected_generation_h_150 | 2.2                      |
| sanity                     | yyyyyy                   |
| parsed_free                | 1.0                      |
| s_per_generated            | 2.203                    |
| grids_ok                   | yn,pa,tf,ab,dose,prob    |
| grids_failed               |                          |
| system_text                |                          |
| mass choice_alarm_A|A      | 0.9994                   |
| mass choice_safe_A|A       | 0.9995                   |
| mass alarm|Anum05          | 0.9991                   |
| mass alarm|Anum1           | 0.999                    |
| mass alarm|Anum2           | 0.9992                   |
| mass para_alarm|A          | 0.9975                   |
| mass para_reversed|A       | 0.9976                   |
| mass alarm|A               | 0.9986                   |
| mass reversed|A            | 0.9979                   |
| mass tf_alarm|A            | 0.9996                   |
| mass tf_reversed|A         | 0.9994                   |

## Problems

- 01-ai/Yi-1.5-9B-Chat-16K: none

## Fresh samples

{
 "physionet2012": {
  "source": "set C",
  "eligible": 3911,
  "eligible_pos": 573,
  "eligible_neg": 3338,
  "per_class": 300,
  "n": 600,
  "fallback_rule_applied": false,
  "card_points_alarm_share": 0.415,
  "prob_exactly_50": 1,
  "overlap_with_earlier_samples": 0,
  "fingerprint": {
   "fresh_ids": "c9555e028ee16b9e",
   "fresh_cards": "fa60197aec5ea6fa"
  },
  "generation_subsample": {
   "150": 300,
   "100": 200
  }
 },
 "physionet2019": {
  "source": "test and dev pools minus the registered test and dev samples",
  "eligible": 10660,
  "eligible_pos": 271,
  "eligible_neg": 10389,
  "per_class": 271,
  "n": 542,
  "fallback_rule_applied": true,
  "card_points_alarm_share": 0.34686346863468637,
  "prob_exactly_50": 7,
  "overlap_with_earlier_samples": 0,
  "fingerprint": {
   "fresh_ids": "9940fba7c625991c",
   "fresh_cards": "dd0a04f4080e72a3"
  },
  "generation_subsample": {
   "150": 300,
   "100": 200
  }
 }
}

## Decisions

{"not_run": ["meta-llama/Llama-3.1-8B-Instruct", "Qwen/Qwen2.5-7B-Instruct", "Qwen/Qwen3-8B", "allenai/Olmo-3-7B-Instruct", "ibm-granite/granite-3.3-8b-instruct", "tiiuae/Falcon3-7B-Instruct"], "grids_not_run": {}, "gen_per_class": 150, "projected_generation_h_at_150": 2.2}
