# Engineering check, fifth study

|                            | 0                                                             | 1                                                                    | 2                  | 3                                                                                                   | 4                                                                                                    | 5                          | 6                        |
|:---------------------------|:--------------------------------------------------------------|:---------------------------------------------------------------------|:-------------------|:----------------------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------------------|:---------------------------|:-------------------------|
| model                      | meta-llama/Llama-3.1-8B-Instruct                              | Qwen/Qwen2.5-7B-Instruct                                             | Qwen/Qwen3-8B      | allenai/Olmo-3-7B-Instruct                                                                          | ibm-granite/granite-3.3-8b-instruct                                                                  | tiiuae/Falcon3-7B-Instruct | 01-ai/Yi-1.5-9B-Chat-16K |
| ok                         | True                                                          | True                                                                 | True               | True                                                                                                | True                                                                                                 | True                       | False                    |
| revision                   | 0e9e39f249a1                                                  | a09a35458c70                                                         | b968826d9c46       | 6e5971d9eba4                                                                                        | 51dd4bc2ade4                                                                                         | 1e57a0ecd176               |                          |
| window                     | 16384.0                                                       | 16384.0                                                              | 16384.0            | 16384.0                                                                                             | 16384.0                                                                                              | 16384.0                    | nan                      |
| tokens_max                 | 2234.0                                                        | 2371.0                                                               | 2354.0             | 2240.0                                                                                              | 2543.0                                                                                               | 2420.0                     | nan                      |
| exact_yn                   | 0.0155                                                        | 0.0469                                                               | 0.0776             | 0.0156                                                                                              | 0.0156                                                                                               | 0.0088                     | nan                      |
| exact_tf                   | 0.0156                                                        | 0.0312                                                               | 0.0469             | 0.0156                                                                                              | 0.0234                                                                                               | 0.0116                     | nan                      |
| exact_ab                   | 0.0128                                                        | 0.0594                                                               | 0.0554             | 0.0156                                                                                              | 0.0156                                                                                               | 0.0078                     | nan                      |
| imputed_timing             | 0.0                                                           | 0.17                                                                 | 0.22               | 0.0                                                                                                 | 0.045                                                                                                | 0.0                        | nan                      |
| s_per_prompt               | 0.5012                                                        | 0.4762                                                               | 0.609              | 0.5349                                                                                              | 0.736                                                                                                | 0.521                      | nan                      |
| projected_scoring_h        | 6.68                                                          | 6.34                                                                 | 8.11               | 7.13                                                                                                | 9.81                                                                                                 | 6.94                       | nan                      |
| projected_generation_h_150 | 2.33                                                          | 1.22                                                                 | 1.0                | 0.39                                                                                                | 1.71                                                                                                 | 0.29                       | nan                      |
| sanity                     | yyyyyy                                                        | yyyyyy                                                               | yyyyyy             | yyyyyy                                                                                              | yyyyyy                                                                                               | yyyyyy                     |                          |
| parsed_free                | 0.5833                                                        | 1.0                                                                  | 1.0                | 1.0                                                                                                 | 0.9583                                                                                               | 1.0                        | nan                      |
| s_per_generated            | 2.3317                                                        | 1.217                                                                | 0.9977             | 0.3933                                                                                              | 1.7052                                                                                               | 0.2905                     | nan                      |
| grids_ok                   | yn,pa,tf,ab,dose,prob                                         | yn,pa,tf,ab,dose,prob                                                | yn,pa,ab,dose,prob | yn,pa,tf,ab,dose,prob                                                                               | yn,pa,tf,ab,dose,prob                                                                                | yn,pa,tf,ab,dose,prob      |                          |
| grids_failed               |                                                               |                                                                      | tf                 |                                                                                                     |                                                                                                      |                            |                          |
| system_text                | Cutting Knowledge Date: December 2023 Today Date: 26 Jul 2024 | You are Qwen, created by Alibaba Cloud. You are a helpful assistant. |                    | You are a helpful function-calling AI assistant. You do not currently have access to any functions. | Knowledge Cutoff Date: April 2024. Today's Date: November 04, 2026. You are Granite, developed by IB |                            |                          |
| mass choice_alarm_A|A      | 0.9979                                                        | 1.0                                                                  | 0.732              | 0.9995                                                                                              | 0.9976                                                                                               | 0.9996                     | nan                      |
| mass choice_safe_A|A       | 0.998                                                         | 1.0                                                                  | 0.536              | 0.9991                                                                                              | 0.9979                                                                                               | 0.9996                     | nan                      |
| mass alarm|Anum05          | 0.9897                                                        | 0.9983                                                               | 0.8457             | 0.9967                                                                                              | 0.9567                                                                                               | 0.9992                     | nan                      |
| mass alarm|Anum1           | 0.9898                                                        | 0.9979                                                               | 0.848              | 0.9962                                                                                              | 0.9658                                                                                               | 0.9992                     | nan                      |
| mass alarm|Anum2           | 0.989                                                         | 0.9973                                                               | 0.8539             | 0.9959                                                                                              | 0.9733                                                                                               | 0.9993                     | nan                      |
| mass para_alarm|A          | 0.9896                                                        | 0.9997                                                               | 0.6549             | 0.9971                                                                                              | 0.893                                                                                                | 0.9985                     | nan                      |
| mass para_reversed|A       | 0.9915                                                        | 1.0                                                                  | 0.5122             | 0.9968                                                                                              | 0.9294                                                                                               | 0.998                      | nan                      |
| mass alarm|A               | 0.9879                                                        | 0.9982                                                               | 0.7773             | 0.9975                                                                                              | 0.9807                                                                                               | 0.9989                     | nan                      |
| mass reversed|A            | 0.9898                                                        | 0.9999                                                               | 0.7693             | 0.9961                                                                                              | 0.9708                                                                                               | 0.9988                     | nan                      |
| mass tf_alarm|A            | 0.987                                                         | 0.9993                                                               | 0.0003             | 0.9992                                                                                              | 0.986                                                                                                | 0.9984                     | nan                      |
| mass tf_reversed|A         | 0.9893                                                        | 0.9995                                                               | 0.0001             | 0.9989                                                                                              | 0.9852                                                                                               | 0.9991                     | nan                      |

## Problems

- meta-llama/Llama-3.1-8B-Instruct: none
- Qwen/Qwen2.5-7B-Instruct: none
- Qwen/Qwen3-8B: none
- allenai/Olmo-3-7B-Instruct: none
- ibm-granite/granite-3.3-8b-instruct: none
- tiiuae/Falcon3-7B-Instruct: none
- 01-ai/Yi-1.5-9B-Chat-16K: error: OSError(30, 'Read-only file system')

## Fresh samples

{
 "physionet2012": {
  "source": "set C",
  "eligible": 3911,
  "eligible_pos": 573,
  "eligible_neg": 3338,
  "per_class": 300,
  "n": 600,
  "fallback_rule_applied": false,
  "card_points_alarm_share": 0.415,
  "prob_exactly_50": 1,
  "overlap_with_earlier_samples": 0,
  "fingerprint": {
   "fresh_ids": "c9555e028ee16b9e",
   "fresh_cards": "fa60197aec5ea6fa"
  },
  "generation_subsample": {
   "150": 300,
   "100": 200
  }
 },
 "physionet2019": {
  "source": "test and dev pools minus the registered test and dev samples",
  "eligible": 10660,
  "eligible_pos": 271,
  "eligible_neg": 10389,
  "per_class": 271,
  "n": 542,
  "fallback_rule_applied": true,
  "card_points_alarm_share": 0.34686346863468637,
  "prob_exactly_50": 7,
  "overlap_with_earlier_samples": 0,
  "fingerprint": {
   "fresh_ids": "9940fba7c625991c",
   "fresh_cards": "dd0a04f4080e72a3"
  },
  "generation_subsample": {
   "150": 300,
   "100": 200
  }
 }
}

## Decisions

{"not_run": ["01-ai/Yi-1.5-9B-Chat-16K"], "grids_not_run": {"qwen3-instruct": ["tf"]}, "gen_per_class": 150, "projected_generation_h_at_150": 6.94}
